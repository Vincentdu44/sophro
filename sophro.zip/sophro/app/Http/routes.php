<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/', function()
{
    return View::make('accueil');
});
Route::get('/applications', function()
{
    return View::make('application');
});
Route::get('/contact', function()
{
    return View::make('contact');
});

// Route::post('/contact','EvenementController@contact')->name('contact');

Route::get('/seance', function()
{
    return View::make('seance');
});

Route::any('/seance','EvenementController@lister')->name('seance.liste');

Route::get('/sophrologues', function()
{
    return View::make('sophrologues');
});

Route::group([
  'prefix' => 'admin', //preficag d'uri /admin
  'middleware' => 'auth'], function () {

Route::get('/evenement', function()
{
    return view('evenement');
});

Route::post('/evenement', 'EvenementController@evenement')->name('evenement');
});

Route::group([
  'prefix' => 'admin', //preficag d'uri /admin
  'middleware' => 'auth'], function () {
Route::any('/clear/{id}', 'EvenementController@clear')->name('clear');

Route::any('/supprimer/{id}', 'EvenementController@supprimer')->name('supprimer');

});

Route::get('/email','EvenementController@mail')->name('email');

Route::get('/admin', function () {
    return view('auth/login');
});

Route::any('/logout','AuthController@out')->name('login.out');

// routes d'authentification
Route::auth();
