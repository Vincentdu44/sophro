<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Evenement;

Use File;

Use Mail;

use App\Contact;

class EvenementController extends Controller
{
  public function evenement(Request $request){
    // enregistrer en bdd

    //créer une nouvelle image en bdd
    $evenement = new Evenement();
    if ($request->hasFile('image')) {
      $destinationPath = public_path("/uploads/");
      $file = $request->file('image');
      $fileName = $file->getClientOriginalName();
      $file->move($destinationPath, $fileName);
      $evenement->image = $fileName;
    }
    $evenement->save();

    return redirect()->route('seance.liste'); //redirige vers
  }

  public function lister(){
    $evenements = Evenement::all();

    return view('seance', [
      'evenements' => $evenements]);
  }

  public function clear($id){
    $destinationPath = public_path("/uploads/");

    File::delete($destinationPath."$id");
      return redirect()->route('seance.liste');
  }

  public function supprimer(Evenement $id){
    $id->delete();

    $evenements = Evenement::all();//récupérer tous les evenements
        return redirect()->route('seance.liste');
  }

  // public function contact(Request $request){
  //   if ($request->isMethod('post')){
  //   $contact = new Contact();
  //   $contact->nom = $request->nom;
  //   $contact->email = $request->email;
  //   $contact->message = $request->message;
  //   $contact->save();
  //
  //   return redirect()->route('email');
  //   };
  // }

  public function mail(Request $request){

    $datas = array(
      "nom" => $request->nom,
      "email" => $request->email,
      "message" => $request->message,
    );
    Mail::send('email',['datas' => $datas],
    function($message) use ($datas) {
      // var_dump($datas);

        $message->from($datas['email'], $datas['nom']);
        $message->to("tot@free.fr", "toto")
        ->subject("MERDE");

    });
    return view('contact');
  }
}
