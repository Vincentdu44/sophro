<title>Contact</title>
<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<head>
  <link rel="stylesheet" href="css/style_contact.css" />
</head>

<main>
  <section id="contact">
    <img src="img/IMG_3093.jpg" alt="moto1" title="moto1" width="70%" height="auto" />
    <h2> Contactez-moi </h2>
    <p></p>
    <form id="formulaire" method="post" action="traitement.php">
      <input type="text" name="prenom" placeholder="Votre prenom:"/>
      <input type="email" name="email" placeholder="Votre mail:"/>
      <textarea name="precisions" rows="4" placeholder="Votre message:"></textarea>
    </form>
  </section>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>