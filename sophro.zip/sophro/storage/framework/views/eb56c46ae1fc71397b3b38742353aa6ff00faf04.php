<div class="container">
  <p><?php echo e($datas['message']); ?>  </p>  
</div>
