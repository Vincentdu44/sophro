<title>Séances</title>
<?php $__env->startSection('content'); ?>

<head>
  <link rel="stylesheet" href="css/style_seance.css" />
</head>

<main>
  <section id="seance">
    <h1>Séances</h1>
    <div class="seance">
      <ul>
        <li>
          <h2> Déroulement d'une séance : </h2>
          <p>Environ 1 heure.</p>
          <p>Accueil (10 à 15 mn) : échange afin d'établir un programme personnalisé.</p>
          <p>Pratique (35 à 40 mn) : exercices assis ou debout, sans contact physique, respiration, mouvement et visualisations.</p>
          <p>Echange sur les sensations durant la séance (5 à 10 mn).</p>
        </li>
        <li>
          <h2> Nombre de séances : </h2>
          <p>Le nombre de séances varie en fonction des personnes et de leur demande. Il faut néanmoins prévoir entre 6 et 10 séances pour ressentir un changement positif.</p>
          <p>Il  n'y a pas de tenue particulière, il faut simplement se sentir à l'aise.</p>
          <p>Refaire le séance chez soi garantit de meilleurs résultats.</p>
          <p>Nous intervenons en cabinet, à domicile, en entreprise ou au sein d'associations.</p>
        </li>
      </ul>
    </div>
    <h3> Tarif : </h3>
    <ul>
      <li>Individuelle : 40 euros.</li>
      <li>Groupe (à partir de 4 personnes) : 15 euros formule 5 séances 60€.</li>
      <li>Entreprises et associations : devis sur demande.</li>
    </ul>
    <h2> Prochain évènement : </h2>
    <?php foreach($evenements as $evenement): ?>
      <div class="evenement">
        <img src="../uploads/<?php echo e($evenement->image); ?>"/>
      </div>
      <a href="<?php echo e(route('supprimer', ['id' => $evenement->id])); ?>">
        <i class="fa fa-trash" aria-hidden="true"></i>
      </a>
      <a href="<?php echo e(route('clear', ['id' => $evenement->image])); ?>">Ne pas garder en mémoire
      </a>
    <?php endforeach; ?>
    <h2> Témoignages : </h2>
    <div class="temoignage">
      <a href="https://www.facebook.com/pg/Lasophrologieetvous-1452509958104402/reviews/?ref=page_internal">
        <img src="img/facebook.png"/>
      </a>
    </div>
  </section>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>