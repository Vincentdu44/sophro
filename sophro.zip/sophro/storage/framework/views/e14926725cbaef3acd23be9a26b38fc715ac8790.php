<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Presentation Sophro</title>
  <link rel="stylesheet" href="css/normalize.css" />
  <link rel="stylesheet" href="dist/flexsider/flexslider.css" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Bree+Serif" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />
  <link rel="stylesheet" href="css/style.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
  <script src="dist/flexsider/jquery.flexslider.js"></script>
<script type="text/javascript">
  $(window).load(function() {
      $('.flexslider').flexslider( {directionNav: false});
    });
</script>
</head>
<body>
  <?php echo $__env->make('partial/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <main>
    <?php echo $__env->yieldContent('content'); ?>
  </main>
  <footer>
    <p>2017 - Réalisé par Vincent Collineau - </p>
  </footer>
  </body>
</html>
