<title>Champs d'applications</title>
<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<head>
  <link rel="stylesheet" href="css/style_application.css" />
</head>

<main>
  <section id="exemples">
    <h1>Champs d'application</h1>
    <h3>Dans la vie quotidienne:</h3>
    <article>
      <ul>
        <li>Gestion du stress, des tensions, de la fatigue</li>
        <li>Améliorer la qualité de son sommeil</li>
        <li>Gestion des phobies</li>
        <li>Gestion de la douleur</li>
        <li>Préparation mental pour les sportifs</li>
        <li>La préparation aux examens</li>
        <li>La prise de parole en public...</li>
      </ul>
      <img src="img/IMG_3095.jpg" alt="sport" title="sport" width="960" height="685" />
      <img src="img/IMG_3094.jpg" alt="grossesse" title="grossesse" width="960" height="640" />
    </article>
    <h3>Et dans le monde de l'entreprise:</h3>
    <article>
      <img src="img/session-1989711__340.png" alt="travail" title="travail" width="408" height="340" class="work" id="work"/>
      <img src="img/team-spirit-1497021__340.jpg" alt="cohesion" title="cohesion" width="510" height="340" class="work"/>
      <ul>
        <li>Gestion du stress et des conflits</li>
        <li>Travail posté</li>
        <li>Prévention des T.M.S</li>
        <li>Fatigue</li>
        <li>Cohésion de groupe...</li>
      </ul>
    </article>
    <p>Cette liste n'est pas exhaustive.</p>
    <p>La sophrologie trouve toute son utilité dans la vie quotidienne.</p>
    <p>Elle s'avere efficace pour gérer les contrariétés de la vie familiale et le stress généré par la performance professionnelle.</p>
    <p>La sophrologie est un véritable art de vivre !</p>
    <p>Nous précisons que la sophrologie est un outil qui demande implication et motivation de votre part.</p>
    <p>Ce n'est pas une méthode médicale et un accompagnement psychologique, elle ne peut en aucun cas remplacer un traitement en cours. Mais elle peut être tout à fait approprié en complément d'un suivi médical ou psychologique.</p>
  </section>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>