<header>
  <nav>
    <a href="/"><img src="<?php echo e(URL::asset('img/shapes.png')); ?>" alt="zen" title="sophro" width="89" height="89" />Sophro</a>
    <ul>
      <li><a href="/"><i class="fa fa-home" aria-hidden="true"></i>Accueil</a></li>
      <li><a href="/sophrologues"><i class="fa fa-user" aria-hidden="true"></i>Qui sommes nous </a></li>
      <li><a href="/applications"><i class="fa fa-folder-open" aria-hidden="true"></i>Champs d'applications</a></li>
      <li><a href="/seance"><i class="fa fa-film" aria-hidden="true"></i>Séances</a></li>
      <li><a href="/contact"><i class="fa fa-envelope" aria-hidden="true"></i>Contact</a></li>
    </ul>
  </nav>
</header>
