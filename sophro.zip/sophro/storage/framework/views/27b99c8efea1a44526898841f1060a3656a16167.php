<title>Qui sommes nous</title>
<?php $__env->startSection('content'); ?>

<head>
  <link rel="stylesheet" href="css/style_sophrologues.css" />
</head>

<main>
  <section id="sophrologues">
    <h1>Qui sommes-nous?</h1>
    <div class="image">
      <img src="img/handshake-2009195_960_720.png" alt="collaboration" title="collaboration" width="960" height="513" />
    </div>
    <p>Notre collaboration est issue de notre profonde amitié, et d'une envie de partager et d'offrir nos expériences, nos compétences et notre sensibilité, qui sont différentes et complémentaires.</p>
    <h2> Des parcours différents mais un même objectif </h2>
    <p>Nous sommes toutes les deux diplômées de l'Institut de Formation de Sophrologie Rhône-Alpes (ISRA) membre de la Fédération des Ecoles Professionnelles en Sophrologie (FEPS), et diplômé RNCP.</p>
    <p>Notre formation correspond à 800 heures d’apprentissage. La validation du diplôme fait suite à un  stage d’application et un mémoire.</p>
    <h4>Anne-Laure :</h4>
    <p>Je suis infirmière de formation . J'ai exercé dans des  services hospitaliers en tant qu'infirmière puis cadre de santé durant 20 ans.</p>
    <p>En tant que sophrologue, je mets à profit mon expérience, à la fois professionnelle et personnelle dans l'accompagnement vers le mieux-être.</p>
    <p>En fin de cursus de formation de sophrologue, j’ai réalisé un stage de mise en application dans une structure d’accueil pour adolescent en rupture familiale sociale et scolaire.</p>
    <h4>Sophie :</h4>
    <p>J’ai été commercial sédentaire dans une entreprise de commerce de gros pour l’industrie durant 15 ans.</p>
    <p>Mon expérience personnel et professionnel des contraintes spécifiques au monde de l’entreprise m’ont permis de mener à bien le stage d’application que j’ai réalisé dans une société spécialisée dans l’automatisme auprès d’ingénieurs, de techniciens et de personnels administratifs.</p>
    <h2> Où exerçons-nous? </h2>
    <div class="map">
      <h3>A domicile autour de Montrond les Bains</h3>
      <iframe src="https://www.google.com/maps/d/embed?mid=1glFN39EW4GO4Vol9TtxGYEyY2m8&hl=fr" width="640" height="480"></iframe>
      <h3>Au cabinet qui se trouve: </h3>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2797.5316451056!2d4.428055215464731!3d45.47923784046097!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47f5ab085140c28f%3A0xcdbf50dd6fca560b!2s1+Rue+Jean+Brossy%2C+42350+La+Talaudi%C3%A8re!5e0!3m2!1sfr!2sfr!4v1487953356090" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
  </section>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>