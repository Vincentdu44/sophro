@extends('welcome')
<title>Presentation Sophro</title>
@section('content')

<section id="flexslider">
<div class="flexslider">
  <ul class="slides">
    <li><img src="img/slider/IMG_3092.jpg" alt="envol" title="envol" width="960" height="640" /></li>
    <li><img src="img/slider/IMG_3090.jpg" alt="chemin" title="chemin" width="960" height="640" /></li>
  </ul>
</div>
</section>
<section id="bienvenue">
  <h1>Bref présentation de la sophro</h1>
  <p>Inspirée de l'hypnose et de disciplines orientales telle que le yoga ou le zen, la sophrologie est une méthode de relaxation de type dynamique.</p>
  <p>Cette pratique psycho-corporelle s'appuie sur des outils simple et disponible à tout moment : </p>
  <div class="bienvenue">
    <ul>
      <li>
        <img src="img/IMG_3096.jpg" alt="respiration" title="respiration" width="70%" height="auto" />
        <h2> la respiration </h2>
      </li>
      <li>
        <img src="img/IMG_3091.jpg" alt="detente" title="detente" width="70%" height="auto" />
        <h2> la détente musculaire </h2>
      </li>
      <li>
        <img src="img/IMG_3097.jpg" alt="visualisation" title="visualisation" width="70%" height="auto" />
        <h2> la visualisation positive </h2>
      </li>
    </ul>
  </div>
  <p>Cette discipline fait partie des thérapies brèves mais peut également se travailler sur le long terme.</p>
  <p>Elle permet de prendre conscience de ses ressources internes et aide à:</p>
  <ul>
    <li>prendre du recul</li>
    <li>améliorer la confiance en soi</li>
    <li>réguler stress et émotions</li>
    <li>relâcher les tensions inutiles</li>
    <li>développer créativité, efficacité...</li>
  </ul>
  <p>La sophrologie a été créée dans les années 60 par le Pr Caycedo, neuropsychiatre colombien, pour aider à soulager les souffrances des malades. Elle s'est rapidement étendu au milieu sportif, social et pédagogique.</p>
  <p>Dans l'entreprise, elle porte essentiellement sur une meilleur gestion du stress, des conflits, des relations, de la concentration et de la créativité.</p>
  <a class="more" href="/applications">En savoir <i class="fa fa-plus-circle" aria-hidden="true"></i></a>
</section>

@endsection('content')
