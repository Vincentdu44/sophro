@extends('welcome')
<title>Contact</title>
@section('content')

<head>
  <link rel="stylesheet" href="css/style_contact.css" />
</head>

<main>
  <section id="contact">
    <img src="img/IMG_3093.jpg" alt="contact" title="contact" width="70%" height="auto" />
    <h2> Contactez-moi </h2>
    <h3>Par téléphone <i class="fa fa-phone" aria-hidden="true"></i>:</h3>
    <p><i class="fa fa-mobile" aria-hidden="true"></i> 0672849996</p>
    <p><i class="fa fa-mobile" aria-hidden="true"></i> 0663235073</p>
    <h3>Par mail <i class="fa fa-envelope-o" aria-hidden="true"></i>:</h3>
    <form id="formulaire" method="get" action="{{ route('email') }}">
      {{ csrf_field() }}
      <input type="text" name="nom" placeholder="Votre prenom:"/>
      <input type="email" name="email" placeholder="Votre mail:"/>
      <textarea name="message" rows="4" placeholder="Votre message:"></textarea>
      <div>
        <button class="btn btn-primary" type="submit">Envoyer</button>
      </div>
    </form>
  </section>
</main>

@endsection('content')
