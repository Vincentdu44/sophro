@extends('welcome')
<title>Champs d'applications</title>
@section('content')

<head>
  <link rel="stylesheet" href="css/style_application.css" />
</head>

<main>
  <section id="exemples">
    <h1>Champs d'application</h1>
    <p>La sophrologie utilise la relaxation dynamique pour aller à la découverte de son corps et de ses capacités souvent peu exploitées,ce qui permet entre autre :</p>
    <h3>Dans la vie quotidienne:</h3>
    <article>
      <ul>
        <li>De gérer le stress, les tensions, la fatigue</li>
        <li>D'améliorer la qualité de son sommeil</li>
        <li>De gérer des phobies</li>
        <li>De gérer la douleur</li>
        <li>De se préparer mentalement pour les sportifs</li>
        <li>De se préparer aux examens</li>
        <li>De prendre la parole en public...</li>
      </ul>
      <img src="img/IMG_3095.jpg" alt="sport" title="sport" width="960" height="685" />
      <img src="img/IMG_3094.jpg" alt="grossesse" title="grossesse" width="960" height="640" />
    </article>
    <i class="fa fa-plus-circle" aria-hidden="true">
    <div class="subMenu">
      <li>D'envisager sa vie sous un autre angle peut être, sous un jour positif, d'être encore plus acteur de sa vie, ne pas avoir l'impression de la subir parfois.</li>
      <li>D'améliorer son confort physique et moral. En repérant ses émotions et en les acceptant, en les utilisant au mieux. Développer la confiance en soi, l'affirmation de soi.</li>
      <li>De cultiver le recul face aux évènements. D'améliorer les relations avec soi et du coup avec les autres.</li>
      <li>De mieux se connaître et se réaliser personnellement et/ou professionnellement en clarifiant, en faisant le point sur ses objectifs.</li>
      <li>De travailler sur sa propre source de motivation. Découvrir ses ressources, ses compétences.</li>
      <li>De développer sa faculté d’adaptation au changement d'en prendre conscience en s'y préparant librement.</li>
      <li>De stimuler les facultés d’attention et de concentration, de confiance en soi dans des moments spécifiques examens, oral d'un concours, prise de parole en publique.</li>
      <li>D'augmenter l’énergie physique et mentale pour optimiser la performance.</li>
      <li>De se préparer à la parentalité aux événements de la vie pas si simples que cela parfois(!).</li>
      <li>D'être accompagné pour préparer une pathologie, une intervention chirurgicale, une situation de soins afin d'améliorer son vécu, sa convalescence.</li>
    </div></i>
    <h3>Et dans le monde de l'entreprise:</h3>
    <article class="entreprise">
      <img src="img/session-1989711__340.png" alt="travail" title="travail" width="408" height="340" class="work" id="work"/>
      <img src="img/team-spirit-1497021__340.jpg" alt="cohesion" title="cohesion" width="510" height="340" class="work"/>
      <ul>
        <li>Gestion du stress et des conflits</li>
        <li>Travail posté</li>
        <li>Prévention des T.M.S</li>
        <li>Fatigue</li>
        <li>Cohésion de groupe...</li>
      </ul>
    </article>
    <p>Cette liste n'est pas exhaustive.</p>
    <p>La sophrologie trouve toute son utilité dans la vie quotidienne.</p>
    <p>Elle s'avere efficace pour gérer les contrariétés de la vie familiale et le stress généré par la performance professionnelle.</p>
    <p>La sophrologie est un véritable art de vivre !</p>
    <p>Nous précisons que la sophrologie est un outil qui demande implication et motivation de votre part.</p>
    <p>Ce n'est pas une méthode médicale et un accompagnement psychologique, elle ne peut en aucun cas remplacer un traitement en cours. Mais elle peut être tout à fait approprié en complément d'un suivi médical ou psychologique.</p>
  </section>
</main>

@endsection('content')
