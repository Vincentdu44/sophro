@extends('welcome')
<title>Evenement</title>
@section('content')

<head>
<link rel="stylesheet" href="<?php echo asset('css/style.css')?>" type="text/css">
</head>

<main>
  <section>
    <h2> Prochain évènement : </h2>
    <form role="form" action="" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
      <div class="box-body">
        <label for="image">Image</label>
        <label for="exampleInputFile">à Ajouter</label>
        <input type="file" name="image" accept="image/*" capture id="exampleInputFile">
      </div>
      <!-- /.box-body -->
      <div class="box-footer">
        <button class="btn btn-primary" type="submit">Enregistrer</button>
      </div>
    </form>
  </section>
</main>

@endsection('content')
